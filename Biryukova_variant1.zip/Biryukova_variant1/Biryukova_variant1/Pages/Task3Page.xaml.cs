﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Biryukova_variant1.Pages
{
    /// <summary>
    /// Логика взаимодействия для Task3Page.xaml
    /// </summary>
    public partial class Task3Page : Page
    {
        private int[] _array;

        public Task3Page()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            _array = new int[15];
            for (int i = 0; i < 15; i++)
                _array[i] = rnd.Next(10, 1000);

            txtArray.Text = string.Join(", ", _array);
            txtResult.Clear();
        }

        private string GetDigitKey(int number)
        {
            char[] digits = Math.Abs(number).ToString().ToCharArray();
            Array.Sort(digits);
            return new string(digits);
        }

        private void btnFind_Click(object sender, RoutedEventArgs e)
        {
            if (_array == null)
            {
                MessageBox.Show("сначала сгенерируйте массив");
                return;
            }

            var groups = _array.GroupBy(GetDigitKey)
                               .Where(g => g.Count() > 1)
                               .ToList();

            if (groups.Count == 0)
            {
                txtResult.Text = "чисел, составленных из одних и тех же цифр, не найдено";
                return;
            }

            var sb = new System.Text.StringBuilder();
            foreach (var g in groups)
                sb.AppendLine($"цифры {{{g.Key}}}: {string.Join(", ", g)}");

            txtResult.Text = sb.ToString();
        }
    }
}
