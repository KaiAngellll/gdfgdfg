﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Biryukova_variant1.Pages
{
    /// <summary>
    /// Логика взаимодействия для Task1Page.xaml
    /// </summary>
    public partial class Task1Page : Page
    {
        public Task1Page()
        {
            InitializeComponent();
        }

        private void txtBinary_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            MessageBox.Show("[" + e.Text + "]");
            //foreach (char c in e.Text)
            //{
            //    int code = (int)c;
            //    MessageBox.Show("Символ: [" + c + "], код: " + code);

            //    if (c != '0' && c != '1')
            //    {
            //        e.Handled = true;
            //        return;
            //    }
            //}
        }
        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            string s = txtBinary.Text.Trim();

            if (string.IsNullOrEmpty(s))
            {
                MessageBox.Show("введите двоичное число");
                return;
            }
            if (s.Length > 10000)
            {
                MessageBox.Show("длина не должна превышать 10000 разрядов");
                return;
            }

            int remainder = 0;
            foreach (char c in s)
                remainder = (remainder * 2 + (c - '0')) % 15;

            txtResult.Text = remainder == 0
                ? "число делится на 15"
                : $"число НЕ делится на 15 (остаток {remainder})";
        }

        private void txtBinary_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtResult_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
