﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Biryukova_variant1.Pages
{
    /// <summary>
    /// Логика взаимодействия для Task4Page.xaml
    /// </summary>
    public partial class Task4Page : Page
    {
        private int[] _array;
        private int _m, _n;

        public Task4Page()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(txtM.Text, out _m) || _m <= 0 ||
                !int.TryParse(txtN.Text, out _n) || _n <= 0)
            {
                MessageBox.Show("введите корректные m и n");
                return;
            }
            Random rnd = new Random();
            _array = new int[_m + _n];
            for (int i = 0; i < _array.Length; i++)
                _array[i] = rnd.Next(1, 100);

            txtOriginal.Text = string.Join(", ", _array);
            txtResult.Clear();

        }

        private void Reverse(int left, int right)
        {
            while (left < right)
            {
                int tmp = _array[left];
                _array[left] = _array[right];
                _array[right] = tmp;
                left++;
                right--;
            }
        }
        private void btnSwap_Click(object sender, RoutedEventArgs e)
        {
            if (_array == null)
            {
                MessageBox.Show("сначала сгенерируйте массив");
                return;
            }

            int total = _m + _n;
            Reverse(0, total - 1);
            Reverse(0, _n - 1);
            Reverse(_n, total - 1);

            txtResult.Text = string.Join(", ", _array);
        }
    }
}
