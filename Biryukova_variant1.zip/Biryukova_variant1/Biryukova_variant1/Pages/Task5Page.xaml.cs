﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Biryukova_variant1.Pages
{
    /// <summary>
    /// Логика взаимодействия для Task5Page.xaml
    /// </summary>
    public partial class Task5Page : Page
    {
        private int[,] _matrix;
        private int _m, _n;

        public Task5Page()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            if (!int.TryParse(txtM.Text, out _m) || _m <= 0 ||
                !int.TryParse(txtN.Text, out _n) || _n <= 0)
            {
                MessageBox.Show("введите корректные M и N");
                return;
            }

            Random rnd = new Random();
            _matrix = new int[_m, _n];
            for (int i = 0; i < _m; i++)
                for (int j = 0; j < _n; j++)
                    _matrix[i, j] = rnd.Next(-10, 11);

            txtOriginal.Text = MatrixToString(_matrix);
            txtAsc.Clear();
            txtDesc.Clear();
            txtResult.Clear();
        }

        private string MatrixToString(int[,] m)
        {
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < m.GetLength(0); i++)
            {
                for (int j = 0; j < m.GetLength(1); j++)
                    sb.Append($"{m[i, j],5}");
                sb.AppendLine();
            }
            return sb.ToString();
        }

        private int[,] SortMatrix(int[,] src, bool ascending)
        {
            int rows = src.GetLength(0), cols = src.GetLength(1);
            int[] flat = new int[rows * cols];
            int k = 0;
            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    flat[k++] = src[i, j];

            Array.Sort(flat);
            if (!ascending)
                Array.Reverse(flat);

            int[,] result = new int[rows, cols];
            k = 0;
            for (int i = 0; i < rows; i++)
                for (int j = 0; j < cols; j++)
                    result[i, j] = flat[k++];

            return result;
        }

        private void btnSort_Click(object sender, RoutedEventArgs e)
        {
            if (_matrix == null)
            {
                MessageBox.Show("сначала сгенерируйте матрицу");
                return;
            }

            txtAsc.Text = MatrixToString(SortMatrix(_matrix, true));
            txtDesc.Text = MatrixToString(SortMatrix(_matrix, false));

            int min = _matrix[0, 0], max = _matrix[0, 0];
            foreach (int v in _matrix)
            {
                if (v < min) min = v;
                if (v > max) max = v;
            }

            txtResult.Text = $"минимум: {min}    максимум: {max}";
        }
    }
}
