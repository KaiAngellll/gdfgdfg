﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Biryukova_variant1.Pages
{
    /// <summary>
    /// Логика взаимодействия для Task2Page.xaml
    /// </summary>
    public partial class Task2Page : Page
    {
        public Task2Page()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, RoutedEventArgs e)
        {
            string s = txtInput.Text.Trim();

            if (string.IsNullOrEmpty(s))
            {
                MessageBox.Show("введите строку");
                return;
            }

            int result;

            if (int.TryParse(s, out _) || long.TryParse(s, out _))
            {
                result = 1;
            }
            else
            {
                string normalized = s.Replace(',', '.');
                double d;
                result = double.TryParse(normalized,
                    System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out d) ? 2 : 0;
            }

            txtResult.Text = result.ToString();
        }
    }
}
